/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo3_10116075_latihan31_.object.oriented.perkenalanmahasiswa;

/**
 *
 *  Nama : DESIS FIRMANSYAH
* Kelas : PBO ULANG 3
* NIM   : 10116075
* Deskripsi Program : program ini berisi program untuk memperkenalkan mahasiswa 
* dengan nim juga dan dari data yang ada
 */
public class PBO3_10116075_Latihan31_ObjectOrientedPerkenalanMahasiswa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Mahasiswa mhs1 = new Mahasiswa();
     mhs1.nim = "10116075";
     mhs1.nama = "DESIS FIRMANSYAH";
     mhs1.perkenalanDiri(mhs1.nim, mhs1.nama);
     
         Mahasiswa mhs2 = new Mahasiswa();
     mhs2.nim = "10116088";
     mhs2.nama = "JAENAB";
     mhs2.perkenalanDiri(mhs2.nim, mhs2.nama);     
        
      Mahasiswa mhs3 = new Mahasiswa();
     mhs3.nim = "101160090";
     mhs3.nama = "GILANG";
     mhs3.perkenalanDiri(mhs3.nim, mhs3.nama);
     
                
      
    }
    
}
